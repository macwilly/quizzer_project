import java.io.File;
import java.io.InputStream;  
import java.util.ArrayList;  
import java.util.List;  
  


import javax.xml.parsers.DocumentBuilder;  
import javax.xml.parsers.DocumentBuilderFactory;  
  


import org.w3c.dom.Document;  
import org.w3c.dom.Element;  
import org.w3c.dom.NodeList;  
import org.w3c.dom.Node;  
  
//import com.xtlh.cn.entity.Book;  
public class xmlDom {
String paperPath="f:/myxmldom/MCS";
String answerPath="f:/myxmldom//quizb.xml";
double paperNum=0;//�Ծ�����
int [] questionAnalysis;
double classAvg;
ArrayList<Result> resultList=new ArrayList<Result>();
	public void parser(String x,String y){
		/*a ���Ծ���·��
		  b �Ǵ𰸵�·��
		 */
		 File aFile=new File(x);
		 File[]files=aFile.listFiles();
		 
		// pathList=files;//c������һ�������ļ����͵��б�pathList
		 if(files!=null)
		 {
			
			 Document doc=null;
				Document doca=null;
		        paperNum=files.length;//�õ��Ծ�����	
		        
				for(int j=0;j<files.length;j++)
				{
				try{
					   DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance(); 
					   DocumentBuilder builder = factory.newDocumentBuilder();  
				       doc = builder.parse(files[j]);

				       doca=builder.parse(y);
				       doc.normalize();//damm its important!
				       doca.normalize();
					}
					catch (Exception e){}
				// TODO Auto-generated method stub
				//NodeList o=doc.getElementsByTagName("name");
				
				
				NodeList n=doc.getElementsByTagName("grade");
				                                      
				NodeList n1=doca.getElementsByTagName("Question");
				NodeList n2=doc.getElementsByTagName("ans");
				
				
				NodeList n3=doc.getElementsByTagName("exam");
				
				//System.out.println(n3.item(0).getAttributes().getNamedItem("stud_UID").getFirstChild().getNodeValue());
		
				
				
				questionAnalysis=new int[n1.getLength()];//����һ����Ŀ�������ȵ�����
				Result rsl=new Result();//�����������
				rsl.name=n3.item(0).getAttributes().getNamedItem("stud_UID").getFirstChild().getNodeValue();
				String[] a=new String[n.getLength()];
			//	rsl.question.grade=a;
				double total=0.0;//ѧ���ķ�
				double max=0.0;//�Ծ��ܷ�
				for(int i=0;i<n.getLength();i++)
				{
					Element q=(Element)n.item(i);//from paper
					Element q1=(Element)n1.item(i);//from answersheet
					Element q3=(Element)n2.item(i);//from answersheet
					
			/*answer by student*/
			//System.out.println(q.getElementsByTagName("ans").item(0).getFirstChild().getNodeValue());
			//String answer=q.getElementsByTagName("ans").item(0).getFirstChild().getNodeValue();
		//	String grade=q.getElementsByTagName("grade").item(0).getFirstChild().getNodeValue();//�����ܷ�
		String answer=q3.getFirstChild().getNodeValue();					
		String grade=q.getFirstChild().getNodeValue();		
		System.out.println(answer+grade);
					
			String standardanswer=q1.getElementsByTagName("answer").item(0).getFirstChild().getNodeValue();
			//System.out.println(standardanswer);
			max+=Double.parseDouble(grade);
			//System.out.println(answer+" "+standardanswer+" "+answer.matches(standardanswer));
			
			if(answer.matches(standardanswer))//������
			{
			//System.out.println(i+" "+"right"+" "+grade);	
			a[i]=grade;
			total+=Double.parseDouble(a[i]);//ת����double���ܷ�
			questionAnalysis[i]+=1;//��������Ե�����+1	
			}
			else if(standardanswer.matches("non-objective-question"))//�������������
			{
//				System.out.println(i+" "+"depends"+" "+youget);
				String youget=q.getElementsByTagName("youget").item(0).getFirstChild().getNodeValue();//����������ڴ��
				a[i]=youget;
				if (Double.parseDouble(youget)>0)
				{questionAnalysis[i]+=1;}//ֻҪ������÷��ˣ���������Ե�����+1
						total+=Double.parseDouble(a[i]);	
			}
			else
			{
//				System.out.println(i+" "+"wrong"+" "+"0");	
			a[i]="0";
			}
			//System.out.println(standardanswer);
				}
				rsl.setAnswer(a);
				rsl.totalScore=total;
				rsl.fullScore=max;
				resultList.add(rsl);
			 
				}
			 
		 }
		
		
		
		
		
		
		
	}
	public void doAnalyze()
	{
		System.out.println("class avg is "+this.classAvg);
		for(int i=0;i<this.questionAnalysis.length;i++)
		{
			System.out.print("Question:"+i+"   correct:"+this.questionAnalysis[i]);
			System.out.println("   "+this.questionAnalysis[i]/paperNum*100+"%");
			
		}
		
		
	}
	
	
	
	
	
	public static void main(String[] args) {
		xmlDom d=new xmlDom();
		double sum=0;//�����˷�����ͣ�Ϊ����ƽ���֣�
		d.parser(d.paperPath, d.answerPath);
		for (Result r:d.resultList)
		{
			sum+=r.totalScore;
			System.out.println(r.toString());
			
			
		}
	d.classAvg=sum/d.paperNum;
		//System.out.println("class avg: "+sum/d.paperNum);
		//System.out.println(aNode.getFirstChild().getFirstChild().getNodeValue());
		d.doAnalyze();
	}

}

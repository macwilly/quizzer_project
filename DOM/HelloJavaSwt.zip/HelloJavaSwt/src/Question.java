
public class Question {
	//String[] grade;
	String[] comment;
	String[] score;
}

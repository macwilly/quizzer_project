


	class Result{
		String name;
		Question question;
		double totalScore;
		double fullScore;
		Result(){
			name="";
			question=new Question();
			totalScore=0.0;
			fullScore=0.0;
			
		}
		public String toString(){
			String rst="student name: ";
			rst+=this.name+"  ";
			for(int i=0;i<this.question.score.length;i++)
			{
				rst+=this.question.score[i]+"|";
				
			}
			rst+="totalscore: "+this.totalScore+" out of "+this.fullScore;
			return rst;
			
			
		}
	    public void setAnswer(String[] s)
	    {
	    	this.question.score=s;
	    	
	    }
}
